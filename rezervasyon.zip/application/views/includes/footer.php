<!-- jQuery -->
<script src="<?php echo FATHER_BASE;?>template/js/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo FATHER_BASE;?>template/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo FATHER_BASE;?>template/js/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo FATHER_BASE;?>template/js/startmin.js"></script>
<script src="<?php echo FATHER_BASE;?>template/js/dropify.js"></script>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
<script>
    $('.menu_item').click(function(){
        $('.subMenu').slideToggle()
    })
    $('.menu-icon').click(function(){
        $('.l-menu').slideToggle()
    })
</script>
</body>
</html>
