<?php include('includes/header1.php');?>
<div class="x-content">
    <?php include('includes/left_nav1.php');?>

    <div class="page-content">
        <div class="main-content">
            <div class="welcome-div">
                
                <div>
                    <img src="<?php echo FATHER_BASE;?>template/img/felix-logo.svg" width="350px"/>
                </div>
                <div class="welcome-msg">Coming soon...</div>
                
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php');?>